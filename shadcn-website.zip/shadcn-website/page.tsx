import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { useEffect } from 'react'

export default function Home() {
  useEffect(() => {
    const audio = document.getElementById('background-music') as HTMLAudioElement;
    
    const playAudio = () => {
      audio.play().catch(error => {
        console.error("Audio play failed:", error);
      });
      document.removeEventListener('click', playAudio);
    };

    document.addEventListener('click', playAudio);

    return () => {
      document.removeEventListener('click', playAudio);
    };
  }, []);

  return (
    <main className="min-h-screen flex flex-col items-center justify-center p-4 font-mono">
      <nav className="mb-12 space-x-2">
        <a href="https://shadcn.com" className="text-[#005be7] hover:underline">
          shadcn
        </a>
        <span>/</span>
        <a href="https://twitter.com/shadcn" className="text-[#005be7] hover:underline">
          twitter
        </a>
        <span>/</span>
        <a href="https://github.com/shadcn" className="text-[#005be7] hover:underline">
          github
        </a>
      </nav>

      <div className="max-w-[600px] text-center mb-12">
        <p className="mb-8">
          I run a newsletter about design,
          <br />
          coding, developer life and open source.
        </p>

        <form className="flex gap-2 justify-center mb-12">
          <Input
            type="email"
            placeholder="m@example.com"
            className="max-w-[240px] font-mono"
          />
          <Button type="submit" className="font-mono">
            Subscribe
          </Button>
        </form>

        <p>
          If you&apos;re looking for the{" "}
          <a href="https://ui.shadcn.com" className="text-[#005be7] hover:underline">
            shadcn/ui
          </a>{" "}
          components, you can find it{" "}
          <a href="https://ui.shadcn.com" className="text-[#005be7] hover:underline">
            here
          </a>
          .
        </p>
      </div>
      <audio id="background-music" loop>
        <source src="/background-music.mp3" type="audio/mpeg" />
        Your browser does not support the audio element.
      </audio>
    </main>
  )
}

